Instructions:

First install everything in requirements.txt by either using pip install one by one or pip install -r requirements.txt
Please make sure the bin file is being extracted properly, if not you can redownload it from:

https://huggingface.co/TheBloke/Llama-2-7B-Chat-GGML/tree/main


NOTE: the Llama2 GGML that is in the folder is the largest one and requires at least 7 GB of unused RAM, 
Please download any other from the link above if this one is too large.


The code uses absolute file paths, please change them according to your specifications, 
the places that need to be changed are commented

Additionally, dfProteinPowder3 is the most refined one so preferably use that

NOTE2: Try to keep the queries short: Instead of asking what is the most popular flavour for the brand diesel, ask: most popular flavour for diesel. This saves chunk space.